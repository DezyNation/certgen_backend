<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Cerificate</title>
</head>

<body>
    <div class="certificate">
        <img src=<?php echo e(asset($image)); ?>>
        <div class="qr">
            <p style="text-align: center; font-size: 12px; margin-bottom: 4px;">Scan QR Code to verify certificate</p>
            <img src="data:image/png;base64, <?php echo e($qrcode); ?>" alt="QR Code">
        </div>
        <h1 class="user_name"><?php echo e($user_name); ?></h1>
        <h5 class="event_name"><?php echo e($event_name); ?></h5>
    </div>
</body>

</html>

<style>

    *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    .certificate {
        position: relative;
        margin: 0 auto;
    }
    .qr {
        position: absolute;
        top: <?php echo e($qr_y); ?>px;
        left: <?php echo e($qr_x); ?>px;
        width: <?php echo e($qr_size); ?>px;
        background-color: #FFF;
        color: #000;
    }

    .user_name {
        position: absolute;
        top: <?php echo e($name_y); ?>px;
        left: <?php echo e($name_x); ?>px;
        font-size: <?php echo e($name_size); ?>px;
    }

    .event_name {
        position: absolute;
        top: <?php echo e($event_y); ?>px;
        left: <?php echo e($event_x); ?>px;
        font-size: <?php echo e($event_size); ?>px;
    }
</style><?php /**PATH /home/u690694409/domains/api.itasinc.in/certgen_backend/resources/views/certificate.blade.php ENDPATH**/ ?>